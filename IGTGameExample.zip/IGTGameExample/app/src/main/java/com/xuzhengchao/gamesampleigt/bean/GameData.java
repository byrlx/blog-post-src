package com.xuzhengchao.gamesampleigt.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * GameData bean
 */
public class GameData implements Parcelable {
    private String name;
    private int jackpot;
    private String date;

    public GameData(String name, int jackpot, String date) {
        this.name = name;
        this.jackpot = jackpot;
        this.date = date;
    }

    public GameData(Parcel in) {
        name = in.readString();
        jackpot = in.readInt();
        date = in.readString();
    }

    public static final Creator<GameData> CREATOR = new Creator<GameData>() {
        @Override
        public GameData createFromParcel(Parcel in) {
            return new GameData(in);
        }

        @Override
        public GameData[] newArray(int size) {
            return new GameData[size];
        }
    };

    public String getName() {
        return name;
    }

    public int getJackpot() {
        return jackpot;
    }

    public String getDate() {
        return date;
    }

    @Override public int describeContents() {
        return 0;
    }

    @Override public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(name);
        parcel.writeInt(jackpot);
        parcel.writeString(date);
    }
}
