package com.xuzhengchao.gamesampleigt.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.TypedValue;

import com.xuzhengchao.gamesampleigt.MainApplication;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class CommonUtils {
    public static boolean isNetOn() {
        ConnectivityManager connectivityManager =
                getService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    public static boolean isWifiConnected() {
        ConnectivityManager connectivityManager =
                getService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        return info.isConnected();
    }

    public static boolean isMobileConnected() {
        ConnectivityManager connectivityManager =
                getService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return info.isConnected();
    }

    /**
     * Get a system service
     *
     * @param name
     * @param <T>
     * @return
     */
    public static <T> T getService(String name) {
        return (T) MainApplication.getInstance().getSystemService(name);
    }

    public static String unicodeToUtf8(String unicodeStr) {
        return unicodeStr;
    }

    public static int dp2px(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                MainApplication.getInstance().getResources().getDisplayMetrics());
    }

    public static String localCurrency(Double number) {
        NumberFormat format = NumberFormat.getCurrencyInstance();
        return format.format(number);
    }
}
