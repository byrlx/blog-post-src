package com.xuzhengchao.gamesampleigt.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.xuzhengchao.gamesampleigt.utils.AvatarManager;
import com.xuzhengchao.gamesampleigt.utils.CommonUtils;
import com.xuzhengchao.gamesampleigt.R;
import com.xuzhengchao.gamesampleigt.utils.ViewUtil;
import com.xuzhengchao.gamesampleigt.bean.Player;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Common header shared by multiple views
 */
public class HeaderView extends LinearLayout {
    Player player;
    TextView name;
    TextView balance;
    TextView lastLogin;
    ImageView avatar;

    public HeaderView(Context context) {
        this(context, null);
    }

    public HeaderView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public HeaderView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        setOrientation(HORIZONTAL);
        View rootView = inflate(context, R.layout.layout_user, this);
        setBackgroundResource(R.color.gray_b9ddc3);
        name = ViewUtil.getView(rootView, R.id.name);
        balance = ViewUtil.getView(rootView, R.id.balance);
        lastLogin = ViewUtil.getView(rootView, R.id.last_login);
        avatar = ViewUtil.getView(rootView, R.id.avatar);
    }

    public void setPlayer(Player player) {
        this.player = player;
        name.setText(player.getName());
        balance.setText(CommonUtils.localCurrency((double) player.getBalance()));

        lastLogin.setText("Last login:" + loginDate());
        AvatarManager.get().loadAvatar(player.getAvatarLink(), avatar);
    }

    private String loginDate() {
        DateFormat format = new SimpleDateFormat("MM/dd/YYYY'T'HH:mm");
        DateFormat format2 = DateFormat.getDateInstance();

        try {
            return format2.format(format.parse(player.getLastLogindate()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }

    public void hideLastLogin() {
        lastLogin.setVisibility(GONE);
    }

    public void showLastLogin() {
        lastLogin.setVisibility(VISIBLE);
    }
}
