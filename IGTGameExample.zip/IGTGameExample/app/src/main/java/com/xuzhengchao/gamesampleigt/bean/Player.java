package com.xuzhengchao.gamesampleigt.bean;

/**
 * Player information
 * <p>
 * Example:
 * {
 * "name": "PlayerName",
 * "balance": 987654,
 * "avatarLink": "https://dl.dropboxusercontent.com/s/8a1j70z1ik3y0q8/user_avatar.png",
 * "lastLogindate": "04/05/2016T16:45"
 * }
 */
public class Player {
    private String name;
    private int balance;
    private String avatarLink;
    private String lastLogindate;

    Player() { }

    public Player(String name, int balance, String avatarLink, String lastLogindate) {
        this.name = name;
        this.balance = balance;
        this.avatarLink = avatarLink;
        this.lastLogindate = lastLogindate;
    }

    public String getName() {
        return name;
    }

    public String getAvatarLink() {
        return avatarLink;
    }

    public int getBalance() {
        return balance;
    }

    public String getLastLogindate() {
        return lastLogindate;
    }
}
