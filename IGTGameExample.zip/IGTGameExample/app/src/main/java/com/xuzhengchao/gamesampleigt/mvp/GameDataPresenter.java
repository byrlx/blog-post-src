package com.xuzhengchao.gamesampleigt.mvp;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.text.format.DateUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.xuzhengchao.gamesampleigt.MainApplication;
import com.xuzhengchao.gamesampleigt.api.IGameApi;
import com.xuzhengchao.gamesampleigt.bean.GameData;

/**
 * Presenter of GameData
 */
public class GameDataPresenter {
    private static final String LAST_FETCH_TIME = "last_fetch_time";
    private static final String GAME_DATA = "game_data";
    private GameDataView view;

    public GameDataPresenter() {
    }

    public GameDataPresenter(GameDataView view) {
        this.view = view;
    }

    public void bind(GameDataView view) {
        this.view = view;
    }

    public void unbind() {
        this.view = null;
    }

    private GameData[] getFromLocal() {
        SharedPreferences pref =
                PreferenceManager.getDefaultSharedPreferences(MainApplication.getInstance());
        long lastFetchTime = pref.getLong(LAST_FETCH_TIME, -1);
        if (System.currentTimeMillis() / DateUtils.HOUR_IN_MILLIS - 1 > lastFetchTime) {
            return null;
        } else {
            return (new Gson()).fromJson(pref.getString(GAME_DATA, ""), GameData[].class);
        }
    }

    private void saveData(GameData[] data) {
        SharedPreferences pref =
                PreferenceManager.getDefaultSharedPreferences(MainApplication.getInstance());
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(GAME_DATA, (new Gson()).toJson(data));
        editor.putLong(LAST_FETCH_TIME, System.currentTimeMillis() / DateUtils.HOUR_IN_MILLIS);
        editor.apply();
    }

    public void load() {
        new Thread(new Runnable() {
            @Override public void run() {

                GameData[] gameData = getFromLocal();
                if (gameData == null) {
                    Log.e("IGT", "get from server");
                    IGameApi gameApi = MainApplication.getInstance().getGameApi();
                    gameData = gameApi.getGameData();
                    saveData(gameData);
                }
                if (gameData != null) {
                    final GameData[] temp = gameData;
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override public void run() {
                            if (view != null) {
                                view.onDataLoaded(temp);
                            }
                        }
                    });
                }
            }
        }).start();
    }
}
