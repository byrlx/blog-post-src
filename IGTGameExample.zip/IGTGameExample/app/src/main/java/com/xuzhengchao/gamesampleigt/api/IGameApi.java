package com.xuzhengchao.gamesampleigt.api;

import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.Player;

import java.util.List;

/**
 * Apis used to get the server data
 */
public abstract class IGameApi {
    public abstract GameData[] getGameData();

    public abstract Player getPlayerInfo();
}
