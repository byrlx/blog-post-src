package com.xuzhengchao.gamesampleigt.api;

import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.GameRequestResult;
import com.xuzhengchao.gamesampleigt.bean.Player;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Implementation of {@link IGameApi}
 */
public class GameApi extends IGameApi {
    public static final String BASE_URL = "https://dl.dropboxusercontent.com/";

    private GameService gameService;

    public GameApi() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        gameService = retrofit.create(GameService.class);
    }

    @Override public GameData[] getGameData() {
        Call<GameRequestResult> call = gameService.getGamesData();
        try {
            GameRequestResult result = call.execute().body();
            if (result != null)
                return result.getGameData();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override public Player getPlayerInfo() {
        Call<Player> call = gameService.getPlayerInfo();

        try {
            return call.execute().body();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
