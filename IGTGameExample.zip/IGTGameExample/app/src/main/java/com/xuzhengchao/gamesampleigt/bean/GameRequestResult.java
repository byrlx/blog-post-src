package com.xuzhengchao.gamesampleigt.bean;

import java.util.List;

/**
 * Result of the Gamedata request
 */
public class GameRequestResult {
    public static final String SUCCESS = "success";
    String response;
    String currency;
    GameData[] data;

    public boolean success() {
        return SUCCESS.equals(response);
    }

    public String getCurrency() {
        return currency;
    }

    public GameData[] getGameData() {
        return data;
    }
}
