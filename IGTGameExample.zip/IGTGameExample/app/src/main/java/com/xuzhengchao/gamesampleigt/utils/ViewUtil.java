package com.xuzhengchao.gamesampleigt.utils;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.util.TypedValue;
import android.view.View;

import com.xuzhengchao.gamesampleigt.MainApplication;

public class ViewUtil {
    /**
     * Get view by id
     */
    public static <T extends View> T getView(@NonNull Activity activity, @IdRes int id) {
        return (T) activity.findViewById(id);
    }

    public static <T extends View> T getView(@NonNull Dialog dialog, @IdRes int id) {
        return (T) dialog.findViewById(id);
    }

    public static <T extends View> T getView(@NonNull View v, @IdRes int id) {
        return (T) v.findViewById(id);
    }

    public static void startActivity(@NonNull Class activityClz) {

        Context context = MainApplication.getInstance();
        Intent it = new Intent(context, activityClz);
        it.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        context.startActivity(it);
    }

    public static int getActionBarSize() {
        Context context = MainApplication.getInstance();
        TypedValue value = new TypedValue();
        context.getTheme().resolveAttribute(android.R.attr.actionBarSize, value, true);
        int sz = TypedValue.complexToDimensionPixelSize(value.data,
                context.getResources().getDisplayMetrics());

        return sz;
    }
}
