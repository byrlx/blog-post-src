package com.xuzhengchao.gamesampleigt.mvp;

import com.xuzhengchao.gamesampleigt.bean.Player;

/**
 * View to show player information
 */
public interface PlayerView {
    void onLoad(Player player);
}
