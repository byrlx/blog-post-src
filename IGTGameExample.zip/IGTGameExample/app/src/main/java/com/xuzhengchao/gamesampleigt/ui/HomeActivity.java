package com.xuzhengchao.gamesampleigt.ui;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.xuzhengchao.gamesampleigt.R;
import com.xuzhengchao.gamesampleigt.utils.ViewUtil;
import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.Player;
import com.xuzhengchao.gamesampleigt.mvp.GameDataPresenter;
import com.xuzhengchao.gamesampleigt.mvp.GameDataView;
import com.xuzhengchao.gamesampleigt.mvp.PlayerPresenter;
import com.xuzhengchao.gamesampleigt.mvp.PlayerView;

public class HomeActivity extends AppCompatActivity implements PlayerView, GameDataView {
    HeaderView mPlayerView;
    RecyclerView mRecyclerView;
    PlayerPresenter mPlayerPresenter;
    GameDataPresenter mGameDataPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mPlayerView = ViewUtil.getView(this, R.id.play_view);
        mRecyclerView = ViewUtil.getView(this, R.id.game_data);

        mPlayerPresenter = new PlayerPresenter(this);
        mGameDataPresenter = new GameDataPresenter(this);

        mPlayerPresenter.loadPlayer();
        mGameDataPresenter.load();
    }

    @Override public void onLoadFail() {

    }

    @Override public void onDataLoaded(GameData[] dataSet) {
        GameDataAdapter adapter = (GameDataAdapter) mRecyclerView.getAdapter();
        if (adapter == null) {
            adapter = new GameDataAdapter(this, dataSet);
            mRecyclerView.setAdapter(adapter);
            mRecyclerView.setLayoutManager(
                    new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        } else {
            adapter.append(dataSet);
        }
    }

    @Override public void onLoad(Player player) {
        mPlayerView.setPlayer(player);
    }
}
