package com.xuzhengchao.gamesampleigt.api;

import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.GameRequestResult;
import com.xuzhengchao.gamesampleigt.bean.Player;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * The retrofit service of http request
 */

public interface GameService {
    @GET("s/2ewt6r22zo4qwgx/gameData.json")
    Call<GameRequestResult> getGamesData();

    @GET("s/5zz3hibrxpspoe5/playerInfo.json")
    Call<Player> getPlayerInfo();
}
