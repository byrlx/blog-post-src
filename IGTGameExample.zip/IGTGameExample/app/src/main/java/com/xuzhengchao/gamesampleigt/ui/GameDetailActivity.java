package com.xuzhengchao.gamesampleigt.ui;

import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.xuzhengchao.gamesampleigt.utils.CommonUtils;
import com.xuzhengchao.gamesampleigt.MainApplication;
import com.xuzhengchao.gamesampleigt.R;
import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.Player;
import com.xuzhengchao.gamesampleigt.databinding.ActivityGameDetailBinding;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class GameDetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityGameDetailBinding binding =
                DataBindingUtil.setContentView(this, R.layout.activity_game_detail);

        GameData data = getIntent().getParcelableExtra("data");
        if (data == null) {
            finish();
            return;
        }

        binding.date.setText("Date: " + localDate(data.getDate()));
        binding.gameName.setText("Name: " + data.getName());
        binding.jackpot.setText("Jackpot: " + CommonUtils.localCurrency((double) data.getJackpot()));

        Gson gson = new Gson();
        final SharedPreferences preferences = PreferenceManager.
                getDefaultSharedPreferences(MainApplication.getInstance());

        String playStr = preferences.getString("player", null);
        binding.playView.hideLastLogin();
        if (!TextUtils.isEmpty(playStr)) {
            Player player = gson.fromJson(playStr, Player.class);
            binding.playView.setPlayer(player);
        }
    }

    public String localDate(String dateStr){
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:SSX");
        DateFormat format2 = DateFormat.getDateInstance();

        try {
            return format2.format(format.parse(dateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return "";
    }
}
