package com.xuzhengchao.gamesampleigt.mvp;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.xuzhengchao.gamesampleigt.MainApplication;
import com.xuzhengchao.gamesampleigt.api.IGameApi;
import com.xuzhengchao.gamesampleigt.bean.Player;

/**
 * Player presenter
 */
public class PlayerPresenter {
    private PlayerView playerView;
    private static final String PLAYER = "player";

    public PlayerPresenter() {

    }

    public PlayerPresenter(PlayerView view) {
        playerView = view;
    }

    public void bind(PlayerView playerView) {
        this.playerView = playerView;
    }

    public void unbind() {
        playerView = null;
    }

    public void loadPlayer() {
        //load from local
        Player player = null;
        final Gson gson = new Gson();

        final SharedPreferences preferences = PreferenceManager.
                getDefaultSharedPreferences(MainApplication.getInstance());

        String playStr = preferences.getString(PLAYER, null);

        if (!TextUtils.isEmpty(playStr)) {
            player = gson.fromJson(playStr, Player.class);
        }

        if (player != null) {
            if (playerView != null) { //check if unbind
                playerView.onLoad(player);
                return;
            }
        }

        //load from server
        new Thread(new Runnable() {
            @Override public void run() {
                IGameApi gameApi = MainApplication.getInstance().getGameApi();
                final Player player1 = gameApi.getPlayerInfo();
                if (player1 != null) {
                    new Handler(Looper.getMainLooper()).post(new Runnable() {
                        @Override public void run() {
                            if (playerView != null) {
                                playerView.onLoad(player1);
                            }
                        }
                    });
                    preferences.edit().putString(PLAYER, gson.toJson(player1)).apply();
                }
            }
        }).start();
    }
}
