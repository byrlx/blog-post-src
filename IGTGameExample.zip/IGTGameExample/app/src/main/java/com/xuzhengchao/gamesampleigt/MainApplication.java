package com.xuzhengchao.gamesampleigt;

import android.app.Application;

import com.xuzhengchao.gamesampleigt.api.GameApi;
import com.xuzhengchao.gamesampleigt.api.IGameApi;

/**
 * A custom application holds some global instance.
 */
public class MainApplication extends Application {
    public static MainApplication sInstance;
    private IGameApi sGameApi;

    @Override public void onCreate() {
        super.onCreate();
        sInstance = this;
        sGameApi = new GameApi();
    }

    public static MainApplication getInstance() {
        return sInstance;
    }

    public IGameApi getGameApi() {
        return sGameApi;
    }
}
