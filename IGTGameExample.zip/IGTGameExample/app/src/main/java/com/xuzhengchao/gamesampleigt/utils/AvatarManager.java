package com.xuzhengchao.gamesampleigt.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.LruCache;
import android.widget.ImageView;

import com.xuzhengchao.gamesampleigt.MainApplication;
import com.xuzhengchao.gamesampleigt.R;

import java.io.IOException;
import java.lang.ref.WeakReference;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A bitmap loader can cache avatar from server
 */
public class AvatarManager {
    private static final int CORNER_DP = 2;
    LruCache<String, Bitmap> cache; //key is the url, value is the bitmap
    private static AvatarManager singleton;
    private final Bitmap placeHolderBitmap;

    public static AvatarManager get() {
        if (singleton == null) {
            synchronized (AvatarManager.class) {
                if (singleton == null) {
                    singleton = new AvatarManager();
                }
            }
        }

        return singleton;
    }

    public void loadAvatar(String url, ImageView imageView) {
        Bitmap avatar = get(url);

        if (avatar == null) {
            if (cancelPotentialWork(url, imageView)) {
                BitmapWorkerTask task = new BitmapWorkerTask(imageView);
                AsyncDrawable drawable = new AsyncDrawable(placeHolderBitmap, task);
                imageView.setImageDrawable(drawable);
                task.execute(url);
            }
        } else {
            imageView.setImageBitmap(avatar);
        }
    }

    private AvatarManager() {
        final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024); //kb
        final int size = maxMemory / 8;
        cache = new LruCache<String, Bitmap>(size) {
            @Override protected int sizeOf(String id, Bitmap bitmap) {
                return bitmap.getByteCount() / 1024;
            }
        };

        placeHolderBitmap = BitmapFactory.decodeResource(MainApplication.getInstance().getResources(),
                R.mipmap.ic_launcher);
    }

    public Bitmap get(String id) {
        return cache.get(id);
    }

    public void add(String id, Bitmap bitmap) {
        if (get(id) == null) {
            cache.put(id, bitmap);
        }
    }

    private boolean cancelPotentialWork(String url, ImageView imageView) {
        BitmapWorkerTask task = getBitmapWorkerTask(imageView);

        if (task != null) {
            final String data = task.url;

            if (data != null && data.equals(url)) {
                task.cancel(true);
            } else {
                return false;
            }
        }

        return true;
    }

    private BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
        if (imageView != null) {
            final Drawable drawable = imageView.getDrawable();
            if (drawable instanceof AsyncDrawable) {
                final AsyncDrawable asyncDrawable = (AsyncDrawable) drawable;
                return asyncDrawable.getBitmapWorkerTask();
            }
        }

        return null;
    }

    class AsyncDrawable extends BitmapDrawable {
        private WeakReference<BitmapWorkerTask> taskWeakReference;

        AsyncDrawable(Bitmap placeholder, BitmapWorkerTask task) {
            super(MainApplication.getInstance().getResources(), placeholder);

            taskWeakReference = new WeakReference<BitmapWorkerTask>(task);
        }

        BitmapWorkerTask getBitmapWorkerTask() {
            return taskWeakReference.get();
        }
    }

    class BitmapWorkerTask extends AsyncTask<String, Void, Bitmap> {
        private WeakReference<ImageView> viewWeakReference;
        private String url;

        BitmapWorkerTask(ImageView view) {
            viewWeakReference = new WeakReference<ImageView>(view);
        }

        @Override protected Bitmap doInBackground(String... params) {
            url = params[0];

            Request request = new Request.Builder().url(url).build();
            try {
                Response response = (new OkHttpClient()).newCall(request).execute();
                if (!response.isSuccessful()) return null;

                Bitmap bitmap = BitmapFactory.decodeStream(response.body().byteStream());

                Bitmap finalBitmap = getRoundedCornerBitmap(bitmap, CommonUtils.dp2px(CORNER_DP));
                add(url, finalBitmap);

                return finalBitmap;
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override protected void onPostExecute(Bitmap bitmap) {
            if (isCancelled()) {
                bitmap = null;
            }

            if (bitmap != null && viewWeakReference != null) {
                ImageView view = viewWeakReference.get();
                final BitmapWorkerTask task = getBitmapWorkerTask(view);

                if (this == task && view != null) {
                    view.setImageBitmap(bitmap);
                }
            }
        }
    }

    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
                .getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }
}
