package com.xuzhengchao.gamesampleigt.ui;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.xuzhengchao.gamesampleigt.R;
import com.xuzhengchao.gamesampleigt.bean.GameData;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * ---- by LX, Mar/15/2017
 */
public class GameDataAdapter extends RecyclerView.Adapter<GameDataAdapter.GameDataViewHolder> {
    private ArrayList<GameData> dataSet;
    private Context context;

    public GameDataAdapter(Context context, GameData[] data) {
        this.dataSet = new ArrayList<>();
        this.dataSet.addAll(Arrays.asList(data));
        this.context = context;
    }

    /**
     * Add more data
     *
     * @param data
     */
    public void append(GameData[] data) {
        this.dataSet.addAll(Arrays.asList(data));
        notifyDataSetChanged();
    }

    @Override
    public GameDataViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.game_item, parent, false);
        return new GameDataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(GameDataViewHolder holder, int position) {
        holder.tvName.setText(dataSet.get(position).getName());
        holder.curPos = position;
    }

    @Override public int getItemCount() {
        return dataSet.size();
    }

    class GameDataViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        int curPos;

        public GameDataViewHolder(View itemView) {
            super(itemView);
            tvName = (TextView) itemView;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) {
                    Intent it = new Intent(context, GameDetailActivity.class);
                    it.putExtra("data", dataSet.get(curPos));
                    context.startActivity(it);
                }
            });
        }
    }
}
