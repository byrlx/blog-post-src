package com.xuzhengchao.gamesampleigt.mvp;

import com.xuzhengchao.gamesampleigt.bean.GameData;

/**
 * View to show game data
 */
public interface GameDataView {
    void onLoadFail();

    void onDataLoaded(GameData[] dataSet);
}
