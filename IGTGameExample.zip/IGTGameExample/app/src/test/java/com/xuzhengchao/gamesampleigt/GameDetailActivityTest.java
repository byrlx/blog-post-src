package com.xuzhengchao.gamesampleigt;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.ui.GameDetailActivity;
import com.xuzhengchao.gamesampleigt.ui.HeaderView;
import com.xuzhengchao.gamesampleigt.utils.CommonUtils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertTrue;

/**
 * ---- by LX, Mar/15/2017
 */
@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class)
public class GameDetailActivityTest {
    @Test
    public void start() {
        //prepare datayyyy-MM-dd'T'HH:mm:SSX
        GameData gameData = new GameData("Game1", 1024, "2011-11-11T12:12:12+08:00");

        //start activity
        Intent it = new Intent(Intent.ACTION_VIEW);
        it.putExtra("data", gameData);
        ActivityController<GameDetailActivity> controller =
                Robolectric.buildActivity(GameDetailActivity.class, it)
                        .create().start();

        GameDetailActivity gameDetailActivity = controller.get();

        controller.resume();

        HeaderView headerView = (HeaderView) gameDetailActivity.findViewById(R.id.play_view);
        TextView tvName = (TextView) gameDetailActivity.findViewById(R.id.game_name);
        TextView tvJackpot = (TextView) gameDetailActivity.findViewById(R.id.jackpot);
        TextView tvDate = (TextView) gameDetailActivity.findViewById(R.id.date);

        assertTrue(headerView != null);
        assertTrue(headerView.findViewById(R.id.last_login).getVisibility() == View.GONE);
        assertTrue(tvName.getText().toString().equals("Name: Game1"));
        assertTrue(tvDate.getText().toString()
                .equals("Date: " + gameDetailActivity.localDate(gameData.getDate())));
        assertTrue(tvJackpot.getText().toString()
                .equals("Jackpot: " + CommonUtils.localCurrency((double) gameData.getJackpot())));
    }
}
