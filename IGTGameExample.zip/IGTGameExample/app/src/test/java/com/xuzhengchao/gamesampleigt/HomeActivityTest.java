package com.xuzhengchao.gamesampleigt;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.xuzhengchao.gamesampleigt.ui.HeaderView;
import com.xuzhengchao.gamesampleigt.ui.HomeActivity;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import static org.junit.Assert.*;

import org.robolectric.RobolectricTestRunner;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

/**
 * ---- by LX, Mar/15/2017
 */
@RunWith(RobolectricTestRunner.class)
@Config(constants = BuildConfig.class)
public class HomeActivityTest {
    @Test
    public void start(){
        ActivityController<HomeActivity> controller =
                Robolectric.buildActivity(HomeActivity.class).create().start();

        HomeActivity homeActivity = controller.get();

        controller.resume();

        HeaderView headerView = (HeaderView)homeActivity.findViewById(R.id.play_view);
        RecyclerView recyclerView = (RecyclerView)homeActivity.findViewById(R.id.game_data);

        assertTrue(headerView != null);
        assertTrue(recyclerView != null);
        assertTrue(headerView.findViewById(R.id.last_login).getVisibility() == View.VISIBLE);

    }
}
