package com.xuzhengchao.gamesampleigt;

import com.xuzhengchao.gamesampleigt.api.IGameApi;
import com.xuzhengchao.gamesampleigt.bean.GameData;
import com.xuzhengchao.gamesampleigt.bean.Player;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * To work on unit tests, switch the Test Artifact in the Build Variants view.
 */
public class GameApiTest {
    private IGameApi gameApi;

    @Before public void init() {
        gameApi = new GameApiImpl();
    }

    @Test
    public void testPlayer() throws Exception {
        Player player = gameApi.getPlayerInfo();
        assertEquals(player.getName(), "helo wold");
        assertEquals(player.getBalance(), 12);
        assertEquals(player.getAvatarLink(), "http://xuzhengchao.com");
        assertEquals(player.getLastLogindate(), "2011-01-01");
    }

    @Test
    public void testGameData() throws Exception{
        GameData[] gameDatas = gameApi.getGameData();
        assertEquals(gameDatas.length, 2);
    }

    class GameApiImpl extends IGameApi {

        @Override public GameData[] getGameData() {
            return new GameData[2];
        }

        @Override public Player getPlayerInfo() {
            return new Player("helo wold", 12, "http://xuzhengchao.com", "2011-01-01");
        }
    }
}